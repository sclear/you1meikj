<template>
  <div class="welcome">
    <div class="weltitme">WELCOME</div>
    <div class="content">欢迎进入优易美后台管理系统</div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  components: {}
};
</script>

<style lang='less' scoped >
.welcome {
  box-sizing: border-box;
  padding: 160px !important;
  .weltitme {
    font-size: 40px;
    color: #4d9aee;
    text-align: center;
  }
  .content{
      font-size: 28px;
      color: #4d9aee;
      text-align: center;
      margin-top: 50px;
      
  }
}
</style>

import { ipUrl } from './env'
const ipurl = ipUrl

export {
    ipurl
}